<template>
  <div class="hello">
    <h1>{{ title }}</h1>
    <button @click="test">子页面的按钮</button>
  </div>
</template>

<script lang="ts">
import { computed, defineComponent, toRefs } from "vue";

export default defineComponent({
  name: "HelloWorld",
  props: {
    title: {
      type: String,
      required: true,
    },
    changeFather: {
      type: Function,
      required: true
    }
  },
  setup(props,context) {
    // 这样就不消除title的响应式了，那么title的响应式体现在哪里
    // const { title } = props;
    const { title } = toRefs(props);
    // const { msg } = props;
    // console.log(msg.value)
    let gai = () => {
      console.log(context)
      context.emit('changeFather')
    };

    const test = ()=> {
      console.log(title)
    }
    return {
      gai,
      test,
      msg2:title
    };
  },
});
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
</style>
