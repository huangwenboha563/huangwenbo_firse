export function demo (str:string) {
    return '你好' + str;
}
